import { createMongoAbility } from '@casl/ability'

export const ability = createMongoAbility()
