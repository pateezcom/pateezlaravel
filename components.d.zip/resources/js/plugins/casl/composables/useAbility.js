import { useAbility as useCaslAbility } from '@casl/vue'

export const useAbility = () => useCaslAbility()
