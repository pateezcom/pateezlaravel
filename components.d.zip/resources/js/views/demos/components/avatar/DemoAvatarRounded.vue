<template>
  <div class="demo-space-x">
    <VAvatar
      rounded="0"
      color="primary"
      icon="tabler-user"
    />

    <VAvatar
      rounded="sm"
      color="secondary"
      icon="tabler-user"
    />

    <VAvatar
      rounded
      color="success"
      icon="tabler-user"
    />

    <VAvatar
      rounded="lg"
      color="info"
      icon="tabler-user"
    />

    <VAvatar
      rounded="xl"
      color="warning"
      icon="tabler-user"
    />

    <VAvatar
      color="error"
      icon="tabler-user"
    />
  </div>
</template>
