<template>
  <div class="demo-space-x">
    <VAvatar
      color="primary"
      icon="tabler-home"
    />

    <VAvatar
      color="secondary"
      icon="tabler-cloud"
    />

    <VAvatar
      color="success"
      icon="tabler-bell"
    />

    <VAvatar
      color="info"
      icon="tabler-user"
    />

    <VAvatar
      color="warning"
      icon="tabler-alert-circle"
    />

    <VAvatar
      color="error"
      icon="tabler-message"
    />
  </div>
</template>
